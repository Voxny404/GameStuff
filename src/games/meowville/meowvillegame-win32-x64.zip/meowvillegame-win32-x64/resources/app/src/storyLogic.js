let isDevelopment = false
let whereIsUserInStory = 0;
let userOption = null;
let nestedStoryLine = 0;

let playerScore = 0
let isMale = null;
let playerName = null

////////    TOOLS    //////////

// changeBackgroundMusic(index)
// changeBackground(index)
// changeBackgroundEffect(index)
// slowlyAddCharacter(msg, Person)
// await setUserSelection('Yeah thank you', 'No')
// nestedStoryPointer(mainStory,userSelection, {
//        1 : {
//            text: 'This works',
//            person: 'A person'
//        },
// })

////////////////////////////////

async function selectStory() {
    let currentStory = null;

    Object.keys(storyObject).forEach(async (el, index) => {
        const story = storyObject[el]
        if (!story && isDevelopment) console.error('Story element missing!', index, story)
        if (whereIsUserInStory == index && story) currentStory = story
        
    });
    
    if (currentStory) {
        
        if (!currentStory.text && !userOption) slowlyAddCharacter('No story found!');
        if (currentStory.text && !currentStory.person && !userOption) slowlyAddCharacter(currentStory.text.replace(/player/g, playerName));
        if (currentStory.text && currentStory.person && !userOption) slowlyAddCharacter(currentStory.text.replace(/player/g, playerName), currentStory.person);
        if (currentStory.background) changeBackground(currentStory.background)
        if (currentStory.music) changeBackgroundMusic(currentStory.music)
        if (currentStory.effect) changeBackgroundEffect(currentStory.effect)


        // setting up prompt for user
        if (currentStory.options) {
            if (isDevelopment) console.log('---User Selection ---', currentStory.options);
            if (!userOption) await setUserSelection(
                currentStory.options[1] ? currentStory.options[1].question : '', 
                currentStory.options[2] ? currentStory.options[2].question : '', 
                currentStory.options[3] ? currentStory.options[3].question : ''
            )
            
            // nested story line
            if (isDevelopment) console.log('Index: '+currentStory.index, 'UserOption: '+ userOption, 'nestedStoryLine: '+ nestedStoryLine);
            if (currentStory.options[userOption] && !currentStory.isEnd) {
                const storyOption = currentStory.options[userOption]

                if (storyOption.playerScore && nestedStoryLine < 2) playerScore += storyOption.playerScore
                nestedStoryPointer(currentStory.index, userOption, storyOption.nestedStoryObject)
            } 

            if (currentStory.options[userOption] && currentStory.isEnd) {
                const storyOption = currentStory.options[userOption]
                const calculate = percentage(playerScore, currentStory.totalPoints)
                if (calculate > 70) nestedStoryPointer(currentStory.index, userOption, storyOption.pass)
                else nestedStoryPointer(currentStory.index, userOption, storyOption.notPass)
            }
        }
    
        if (nestedStoryLine == 0) whereIsUserInStory += 1
    } else {
        console.log('player score: ' + playerScore);
        resetGame()
    }
}

function percentage(partialValue, totalValue) {
    return (100 * partialValue) / totalValue;
}

function resetGame() {
    // end
    changeBackground(0)
    changeBackgroundEffect(0)
    changeBackgroundMusic(0)
    slowlyAddCharacter('','')
    whereIsUserInStory = 0;
    userOption = null;
    nestedStoryLine = 0;
    playerScore = 0
    isMale = null;
    playerName = null
    introScreen(isComingBack = true)
    if (isDevelopment) console.log(`GAME RESET`);
}