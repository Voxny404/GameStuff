// EXAMPLE
// 5: {
//     text: 'Now select something',
//     person: 'John Furrball',
//     background: 1,
//     music:1,
//     effect: 4,
//     index: 5,
//     options: {
//         1: {
//             playerScore: 1,
//             question: 'I like this &player',
//             nestedStoryObject : {
//                 1 : {
//                     text: 'This works',
//                     person: 'Romeo Paws'
//                 },
//                 2 : {
//                     text: 'Good you rock',
//                     person: 'Iris Pawkins'
//                 }
//             }
//         },
//         2: {
//             question: 'No way this works',
//             nestedStoryObject : {
//                 1 : {
//                     text: 'This Sounds good',
//                     person: 'Iris Pawkins'
//                 },
//                 2 : {
//                     text: 'Good Job my dear',
//                     person: 'John Furrball'
//                 }
//             }
//         },
//     }
// },
// 4: {
//     text:"",
//     person: '',
// },
const storyObject = {
    0: {
        text: 'Once upon a time, in a land far away, there was a small city called Meowville. It was a place filled with people, who lived together in harmony despite their different breeds, colours, and sizes.',
        person: '',
        background: 3,
        music: 3,
        effect: 1,
    },
    1: {
        text: "The people of Meowville were very proud of their city and the way they had built it up. They had created a bustling economy, with shops and markets, and a strong educational system that all people were encouraged to take advantage of.",
        person: '',
    },
    2: {
        text: "But, as with all great cities, Meowville was not without its problems. A group of people from a far away kingdom, called the Doggies, had started to encroach on their city and were taking over.",     
        person: '',
    },
    3: {
        text: "The people of Meowville worked together to create a plan to stop the Doggies. They formed a militia of people, who were trained in the art of combat, and they set up a series of defence mechanisms to protect their city.",
        person: '',
    },
    4: {
        text:"The people of Meowville worked hard, and eventually they were able to push the Doggies back, and reclaim their beloved city. The people of Meowville celebrated their victory with a great parade, where they paraded through the streets, singing and dancing.",
        person: '',
    },
    5: {
        text:"Many years later, the people of Meowville still look fondly on their victory, and the people of Meowville remain prideful",
        person: '',
    },
    6: {
        text:"Hey there! Are you alright?",
        person: '...',
        background: 2,
        music: 2,
        effect: 3,
    },
    7: {
        text:"Someone asked you, her friendly demeanour and kind eyes making her approachable.",
        person: '',
    },
    8: {
        text:"Is there anything I can do to help?",
        person: '...',
        index: 8,
        options: {
            1: {
                question: 'Who are you?',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "I'm Sunny! I'm from Meowville and I'm the youngest of two children. I know I can make a difference in the world if I try hard enough! That's why im out here.",
                        person: 'Sunny Paws'
                    },
                }
            },
            2: {
                question: 'Where am I?',
                nestedStoryObject : {
                    1 : {
                        text: "We're right here in Meowville, inside a cave. Meowville is the best place in the world! I'm so glad I get to live here.",
                        person: 'Sunny Paws'
                    },
                }
            },
        }
    },
    9: {
        text:"You attempt to introduce yourself, yet you find you cannot recall even your own name.",
        person: '',
    },
    10: {
        text:"Oh dear! It seems like you have difficulty retaining your memories?",
        person: 'Sunny Paws',
        index: 10,
        options: {
            1: {
                question: 'Yes!',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Well, it's not the end of the world, I say, let's try to stay positive. I'm sure your memories will come back soon. In the meantime, let's focus on the things we can do now.",
                        person: 'Sunny Paws'
                    },
                    2 : {
                        text : "Oh! I know. We can go back to my place until you regain your memories.",
                        person: 'Sunny Paws'
                    }
                }
            },
            2: {
                question: 'No!',
                nestedStoryObject : {
                    1 : {
                        text: "Are you certain? You don't seem very confident.",
                        person: 'Sunny Paws'
                    },
                    2 : {
                        text : "Anyway, let's go back to my place until you feel better.",
                        person: 'Sunny Paws'
                    }
                }
            },
        }
    },
    11: {
        text:"By the way, what should I call you ?",
        person: 'Sunny Paws',
    },
    12: {
        text:"Oh!",
        person: 'Sunny Paws',
    },
    13: {
        text:"How about I call you player for the time being.",
        person: 'Sunny Paws',
    },
    14: {
        text:"I think it sounds great!",
        person: 'Sunny Paws',
    },
    15: {
        text:"You and Sunny set off, heading towards her home. The sun shone brightly above as you laughed and talked, the warm breeze of the day making the journey all the more pleasant.",
        person: '',
    },
    16: {
        text:"As you arrived, you couldn't help but feel a sense of anticipation. What would this new place hold in store for you?",
        person: '',
    },
    17: {
        text:"Oh who is this Sunny?",
        person: '...',
        background: 5,
        music: 4,
        effect: 2,
    },
    18: {
        text:"Oh this is player, This is my brother Romeo.",
        person: 'Sunny Paws',
    },
    19: {
        text:"He's the best brother ever and I'm lucky to have him!",
        person: 'Sunny Paws',
    },
    20: {
        text:"Romeo. player can't remember anything!",
        person: 'Sunny Paws',
        music: 2,
    },
    21: {
        text:"Hi there! I'm Romeo. It's nice to meet you player. I hope my little sister didn't cause you too much of a ruckus!",
        person: 'Romeo Paws',
        index: 21,
        options: {
            1: {
                question: 'No, not at all.',
                playerScore: 3,
                nestedStoryObject : {
                    1 : {
                        text: "I am glad to hear that.",
                        person: 'Romeo Paws',
                    },
                }
            },
            2: {
                question: 'She was so annoying!',
                nestedStoryObject : {
                    1 : {
                        text: "Sunny!",
                        person: 'Romeo Paws'
                    },
                    2 : {
                        text : "Oh, I'm so sorry! I didn't mean to take control of everything. I just wanted to make sure player was having fun. I'll try to be more mindful of that in the future.",
                        person: 'Sunny Paws'
                    },
                    3 : {
                        text : "I'll try to be more mindful of that in the future.",
                        person: 'Sunny Paws'
                    }
                }
            },
        }
    },
    22: {
        text:"Alright then. You guys have fun. I gotta go meet with John. He needs to read my new book. Do you want to take a peak too ?",
        person: 'Romeo Paws',
        index: 22,
        options: {
            1: {
                question: 'Not bad!',
                nestedStoryObject : {
                    1 : {
                        text: "Oh! Okay then, Thanks I will be off now.",
                        person: 'Romeo Paws',
                    },
                }
            },
            2: {
                question: 'I hate it!',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Why?",
                        person: 'Romeo Paws'
                    },
                    2 : {
                        text : "Perhaps instead of the villain feeling like they were being passive, they should be more aggressive and relentless in their pursuit of the protagonist.",
                        person: 'Romeo Paws'
                    },
                    3 : {
                        text : "This can be done by having them actively seek out the protagonist, plotting and scheming ways to make their lives more difficult, and showing no mercy when they have them in their sights.",
                        person: 'Romeo Paws'
                    },
                    4 : {
                        text : "This will make the villain more threatening and their actions more menacing, creating a sense of dread and suspense for the reader.",
                        person: 'Romeo Paws'
                    },
                    5 : {
                        text : "YES that's it. I will change that right away!",
                        person: 'Romeo Paws'
                    },
                    6 : {
                        text : "Okay …",
                        person: 'Sunny Paws'
                    },
                    7 : {
                        text : "What about John? Oh well there he goes.",
                        person: 'Sunny Paws'
                    }
                }
            },
        }
    },
    23: {
        text:"What should we do now? Let's go on an adventure and explore the forest to see if we can find anything that can trigger your memories, or we can head to the library and search for someone who knows more than I do!",
        person: 'Sunny Paws',
        index: 23,
        options: {
            1: {
                question: "Let's go to the forest.",
                playerScore: 5,
                nestedStoryObject : {
                    1 : {
                        text: "What a great choice!",
                        person: 'Sunny Paws',
                    },
                    2 : {
                        text: " I'm so excited to go to the forest and explore.",
                        person: 'Sunny Paws',
                    },
                    3 : {
                        text: "I'm sure We'll be able to find some old memories and create some new ones.",
                        person: 'Sunny Paws',
                    },
                    4 : {
                        text: "Let's go!",
                        person: 'Sunny Paws',
                    },
                }
            },
            2: {
                question: "Let's go to the library.",
                nestedStoryObject : {
                    1 : {
                        text: "Why don't we go to the forest and do some outdoor activities?",
                        person: 'Sunny Paws'
                    },
                    2 : {
                        text : "Don't tell me you are afraid of the Doggies.",
                        person: 'Sunny Paws'
                    },
                    3 : {
                        text : "Oh dear!",
                        person: 'Sunny Paws'
                    },
                    4 : {
                        text : "Don't worry about it. That was ages ago.",
                        person: 'Sunny Paws'
                    },
                    5 : {
                        text : "The Doggies are a group of people from a far away kingdom who had started to encroach on Meowville and were taking over. ",
                        person: 'Sunny Paws'
                    },
                    6 : {
                        text : "Eventually, the people of Meowville were able to push the Doggies back and reclaim their city.",
                        person: 'Sunny Paws'
                    },
                    7 : {
                        text : "So the story goes. But that was a long time ago.",
                        person: 'Sunny Paws'
                    },
                    8 : {
                        text : "So off to the forest!",
                        person: 'Sunny Paws'
                    }
                }
            },
        }
    },
    24: {
        text:"Sunny's secret plan is to surprise player with a romantic picnic set up in the forest. She plans to bring along a blanket, some food and drinks, and candles to create a romantic atmosphere for her and player.",
        person: '',
    },
    25: {
        text:"She hopes that this will be a special moment between the two of them and will help to further solidify their relationship",
        person: '',
    },
    26: {
        text:"On their way there however.",
        person: '',
    },
    27: {
        text:"You idiots out of my way!",
        person: '...',
        background: 1,
        music: 1,
        effect: 4,
    },
    28: {
        text:"Uh…?",
        person: 'Sunny Paws',
    },
    29: {
        text:"AAAAAAAHHHHH!!!!!",
        person: '...',
    },
    30: {
        text:"Is that a …?",
        person: 'Sunny Paws',
    },
    31: {
        text:"RUN!!!!",
        person: '...',
    },
    32: {
        text:"It's a boar!!!!",
        person: '...',
    },
    33: {
        text:"The stranger quickly leapt into action, running towards the boar and brandishing his spear. He shouted in a loud voice, hoping to divert the boar's attention away from the group. He was determined to protect the group from harm, and he knew he had to act fast.",
        person: '',
    },
    34: {
        text:"He lunged forward and thrust his spear into the boar's side, bringing it down to the ground. The stranger smiled in relief as he watched the boar stumble away from the group",
        person: '',
    },
    35: {
        text:"He had done it - he had saved the group from danger.",
        person: '',
    },
    36: {
        text:"Ah, the dangers of the wild, they are nothing to fear! For I, Killerclaw, am here to keep the city of Meowville safe and sound!",
        person: '...',
    },
    37: {
        text:"With my sharp claws and keen senses, I shall protect all who dwell within its walls!",
        person: 'Killerclaw Furr',
    },
    38: {
        text:"That's not fair!",
        person: 'Sunny Paws',
    },
    39: {
        text:"I worked so hard on that plan and now it's ruined because of you!",
        person: 'Sunny Paws',
    },
    40: {
        text:"Why did you have to do that?",
        person: 'Sunny Paws',
    },
    41: {
        text:" You know, it's not nice to ruin other people's plans without even asking.",
        person: 'Sunny Paws',
    },
    42: {
        text:"I’m sorry. I really mean it.",
        person: 'Killerclaw Furr',
    },
    43: {
        text:"Oh I know what about an adventure?",
        person: 'Killerclaw Furr',
    },
    44: {
        text:"Well, we are already on an adventure.",
        person: 'Sunny Paws',
    },
    45: {
        text:"Oh I know what about an adventure?",
        person: 'Killerclaw Furr',
        index: 45,
        options: {
            1: {
                question: 'No.',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Well I didn't ask you!",
                        person: 'Killerclaw Furr',
                    },
                    2 : {
                        text: "Sure! The more the merrier! ",
                        person: 'Sunny Paws',
                    },
                    3 : {
                        text: "Alright so what's the adventure about ?",
                        person: 'Killerclaw Furr',
                    },
                    4 : {
                        text: "To get player's memories back",
                        person: 'Sunny Paws',
                    },
                    5 : {
                        text: "Ah I see. What about we ditch this person over here?",
                        person: 'Killerclaw Furr',
                    },
                    6 : {
                        text: "Would you care to join me for a romantic evening under the stars?",
                        person: 'Killerclaw Furr',
                    },
                    7 : {
                        text: "I know just the place - a secret alcove near the edge of the forest, where the stars shine brightest. I can promise you a night you won't soon forget!",
                        person: 'Killerclaw Furr',
                    },
                    8 : {
                        text: "I think I have to pass on that you smell like a boar.",
                        person: 'Sunny Paws',
                    },
                    9 : {
                        text: " Alright fine. Let's just continue with this adventure. I know have you guys tried the library yet ?",
                        person: 'Killerclaw Furr',
                    },
                }
            },
            2: {
                question: 'Yes!',
                nestedStoryObject : {
                    1 : {
                        text: "Alright so what's the adventure about ?",
                        person: 'Killerclaw Furr',
                    },
                    2 : {
                        text: "To get player's memories back",
                        person: 'Sunny Paws',
                    },
                    3 : {
                        text : "How did you even lose your memories in the first place ? Oh sorry my bad …",
                        person: 'Killerclaw Furr'
                    },
                    4 : {
                        text : "Well! I'm ready for an adventure! I'm sure it's going to be full of excitement. Oh I know have you guys tried the library yet ?",
                        person: 'Killerclaw Furr'
                    }
                }
            },
        }
    },
    46: {
        text:"Ah-ha! This one over here thought the forest would've been a better idea.",
        person: 'Sunny Paws',
    },
    47: {
        text:"I told you the library is a better place to start to begin with.",
        person: 'Sunny Paws',
        index: 47,
        options: {
            1: {
                question: 'What do you mean!',
                nestedStoryObject : {
                    1 : {
                        text: "Be silent now, or I'll come for you in the dead of night when you're snuggled up in bed!",
                        person: 'Whispering Sunny',
                    },
                }
            },
            2: {
                question: 'Yeah it was my idea!',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Thanks.",
                        person: 'Whispering Sunny',
                    },
                }
            },
        }
    },
    48: {
        text:"Why are we whispering?",
        person: 'Whispering Killerclaw',
    },
    49: {
        text:"Ahaha! Don't mind that anyway, let's go to the library!",
        person: 'Sunny Paws',
    },
    50: {
        text:"The sun had set and the sky was now dark. A cool breeze came through the open window, rustling the curtains. In the distance, an owl hooted in the night, its call echoing through the darkness.",
        person: '',
        background: 4,
        music: 3,
        effect: 2,
    },
    51: {
        text:"Good evening everyone! My name is Iris, and I'm so pleased to meet you all.!",
        person: '...',
    },
    52: {
        text:"My name is Iris, and I'm so pleased to meet you all.",
        person: 'Iris Pawkins',
    },
    53: {
        text:"I'm a lifelong learner and a lover of books, and I'm always looking for new opportunities to broaden my knowledge. I'm excited to share my knowledge with you all tonight.",
        person: 'Iris Pawkins',
    },
    54: {
        text:"So please, ask me anything!",
        person: 'Iris Pawkins',
    },
    55: {
        text:"Oh it's you Killerclaw!",
        person: 'Iris Pawkins',
    },
    56: {
        text:"Yo Iris how do you do?",
        person: 'Killerclaw Furr'
    },
    57: {
        text:"Killerclaw, I appreciate your feelings, but I'm not interested in getting back together. I hope you understand that.",
        person: 'Iris Pawkins',
    },
    58: {
        text:"Yeah I know, don't worry about that. However if you …",
        person: 'Killerclaw Furr'
    },
    59: {
        text:"No!",
        person: 'Iris Pawkins',
        index: 59,
        options: {
            1: {
                question: "Tell her you lost your memories.",
                nestedStoryObject : {
                    1 : {
                        text: "Oh no really! How strange! No this can't be.",
                        person: 'Iris Pawkins',
                    },
                    2 : {
                        text: "But player can't remember a single thing that's why we are here.",
                        person: 'Killerclaw Furr'
                    },
                    3 : {
                        text: "This morning, one of my experiments went terribly wrong - I had been attempting to create a potion to rewrite someone's memories to make them fall in love with me, like some kind of anime-style love potion.",
                        person: 'Iris Pawkins',
                    },
                    4 : {
                        text: "But it seems to have disappeared into thin air!",
                        person: 'Iris Pawkins',
                    },
                    5 : {
                        text: "Anime-style love potion? Are you still in love with me my dear!",
                        person: 'Killerclaw Furr'
                    },
                    6 : {
                        text: "No! I am joking of course. However I do have some things missing.",
                        person: 'Iris Pawkins',
                    },
                    7: {
                        text: "A powdered Moonstone, ground dragon claw's and most importantly my pillow!",
                        person: 'Iris Pawkins',
                    },
                    8 : {
                        text: "Your pillow ?",
                        person: 'Sunny Paws',
                    },
                    9: {
                        text: "Yes my pillow when I woke up the pillow was gone!",
                        person: 'Iris Pawkins',
                    },
                    10 : {
                        text: "You mean this pillow on the ground?",
                        person: 'Sunny Paws',
                    },
                    11: {
                        text: "Ahhh my goodness you found it!",
                        person: 'Iris Pawkins',
                    },
                }
            },
            2: {
                question: 'Say nothing.',
                nestedStoryObject : {
                    1 : {
                        text: "Anyways we are here on a quest!",
                        person: 'Sunny Paws',
                    },
                    2 : {
                        text: "Oh? A quest ?",
                        person: 'Iris Pawkins',
                    },
                    3 : {
                        text: "Yes Killerclaw decided to live his life as a boar from now on.",
                        person: 'Sunny Paws',
                    },
                    4 : {
                        text: "Wonderful! He certainly smells like a boar already and as fate might have it I have just the thing for it.",
                        person: 'Iris Pawkins',
                    },
                    5 : {
                        text: "Ahhh no, please don't!",
                        person: 'Killerclaw Furr'
                    },
                    6 : {
                        text: "What is this strange, sticky substance?",
                        person: 'Killerclaw Furr'
                    },
                    7 : {
                        text: "I can feel myself starting to transform - what do I do?! AHHHHHH, no!",
                        person: 'Killerclaw Furr'
                    },
                    8 : {
                        text: "This is a nightmare! I must find a way to reverse this transformation before it's too late!",
                        person: 'Killerclaw Furr'
                    },
                    9 : {
                        text: "Relax, it is just a deodorant.",
                        person: 'Iris Pawkins',
                    },
                    10 : {
                        text: "Ah this is better thank you so much. ",
                        person: 'Sunny Paws',
                    },
                    11 : {
                        text: "No problem. Now what is the real reason you wanted to come see me ?",
                        person: 'Iris Pawkins',
                    },
                    12 : {
                        text: "Well our friend over here has lost their memories.",
                        person: 'Sunny Paws',
                    },
                    13 : {
                        text: "I see.",
                        person: 'Iris Pawkins',
                    },
                }
            },
        }
    },
    60: {
        text:"Let's discuss this further over some tea",
        person: 'Iris Pawkins',
        index: 60,
        options: {
            1: {
                question: 'I want coffee.',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Sorry but coffee is out.",
                        person: 'Iris Pawkins',
                    },
                }
            },
            2: {
                question: 'I love tea',
                nestedStoryObject : {
                    1 : {
                        text: "Is that so?",
                        person: 'Iris Pawkins',
                    },
                }
            },
        }
    },
    61: {
        text:"Hey Iris are you there?",
        person: ''
    },
    62: {
        text:"Yes John we are over at the table.",
        person: 'Iris Pawkins',
    },
    63: {
        text:"We ?",
        person: 'John Furrball'
    },
    64: {
        text:"Oh! Hello there I'm John! I am an old friend of Iris. We both go way back.",
        person: 'John Furrball'
    },
    65: {
        text:"Don't forget why we are here John!",
        person: 'Romeo Paws'
    },
    66: {
        text:"Oh yeah that's right Iris we wanted to talk to you about something.",
        person: 'John Furrball'
    },
    67: {
        text:"Wow tonight is a pretty busy night.",
        person: 'Iris Pawkins',
    },
    68: {
        text:" Sounds like someone is having fun. How about we explore the back rooms together and I show you some secrets that will take your breath away?",
        person: 'Whispering Sunny',
        index: 68,
        options: {
            1: {
                question: 'Decline.',
                nestedStoryObject : {
                    1 : {
                        text: "Sorry my sister can sometimes be a little troublesome.",
                        person: 'Whispering Romeo'
                    },
                    2 : {
                        text: "Why are we whispering again I don't get it!",
                        person: 'Whispering Killerclaw'
                    },
                    3 : {
                        text: "Stupid boar man.",
                        person: 'Whispering Sunny'
                    },
                }
            },
            2: {
                question: 'YES!',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Ahaha I was just joking my dear.",
                        person: 'Whispering Sunny'
                    },
                    2 : {
                        text: "Sister you shouldn't make jokes like that.",
                        person: 'Romeo Paws'
                    },
                    3 : {
                        text: "I am sorry I just couldn't resist.",
                        person: 'Sunny Paws',
                    },
                    4 : {
                        text: "Resist what ?",
                        person: 'Killerclaw Furr'
                    },
                    5 : {
                        text: "Be a quiet boar man!",
                        person: 'Sunny Paws',
                    },
                    6 : {
                        text: "So you're, boar man ?!",
                        person: 'Romeo Paws'
                    },
                    7 : {
                        text: "Yes!",
                        person: 'Killerclaw Furr'
                    },
                    8 : {
                        text: "I mean noooo ...",
                        person: 'Killerclaw Furr'
                    },
                }
            },
            3: {
                question: 'Ask Killerclaw for help!',
                nestedStoryObject : {
                    1 : {
                        text: "Hey Sunny How about we explore the wilds of our own kind?",
                        person: 'Killerclaw Furr'
                    },
                    2 : {
                        text: "We can explore each other's hearts and souls. Let's create our own adventure and make some beautiful memories together.",
                        person: 'Killerclaw Furr'
                    },
                    3 : {
                        text: "Who are you?",
                        person: 'Romeo Paws'
                    },
                    4 : {
                        text: "Oh that is boar man!",
                        person: 'Sunny Paws',
                    },
                    5 : {
                        text: "Hello Boar man. I love your spirit, your courage and your passion. Let's go to the back rooms and talk a little more.",
                        person: 'Romeo Paws'
                    },
                }
            },
        }
    },
    69: {
        text:"So you lost your memories?",
        person: 'John Furrball',
        index: 69,
        options: {
            1: {
                question: 'Yes.',
                nestedStoryObject : {
                    1 : {
                        text: "If you don't mind I'll try and help you on your quest together we can break this curse!",
                        person: 'John Furrball',
                    },
                }
            },
            2: {
                question: 'No.',
                nestedStoryObject : {
                    1 : {
                        text: "Oh my bad then. Iris told me so. So I thought …",
                        person: 'John Furrball',
                    },
                    2 : {
                        text: "Yeah they are messing with you John.",
                        person: 'Iris Pawkins',
                    },
                    3 : {
                        text: "Oh sorry I am sometimes a little off track so please do forgive me.",
                        person: 'John Furrball',
                    },
                }
            },
        }
    },
    70: {
        text:"I heard a rumour going around that there is someone going around erasing people's memories and it is in close connections to the Doggies.",
        person: 'John Furrball',
    },
    71 : {
        text: "The Doggies ?",
        person: 'Iris Pawkins',
    },
    72 : {
        text: "I thought the group doesn't exist anymore ?",
        person: 'Sunny Paws',
    },
    73: {
        text:"Well rumour has it that they operate in the shadows since then.",
        person: 'John Furrball',
    },
    74 : {
        text: "Right. This is why we wanted to talk to you Iris.",
        person: 'Romeo Paws'
    },
    75 : {
        text: "What's so scary about a bunch of poppies?",
        person: 'Killerclaw Furr'
    },
    76 : {
        text: "They aren't a bunch of poppies! The doggies in Meowville were brutale because their population had grown out of control.",
        person: 'Iris Pawkins',
    },
    77 : {
        text: "This caused them to become more aggressive and territorial, leading to frequent fights with others with different beliefs. As a result, they began encroaching on the city of Meowville, making it harder for the citizens to feel safe and secure.",
        person: 'Iris Pawkins',
    },
    78 : {
        text: "The city has since taken steps to remedy the issue, such as establishing a no-kill policy to work with local law enforcement to ensure that the cult is not able to cause further harm.",
        person: 'Iris Pawkins',
    },
    79 : {
        text: "What are the beliefs held by them?",
        person: 'Sunny Paws',
    },
    80 : {
        text:"The doggies of Meowville are a cult that believes in a radical version of the religion of Meowism. They believe that they are the chosen ones and that they need to protect Meowville from those who would do it harm.",
        person: 'Iris Pawkins',
    },
    81 : {
        text:"They also believe that they have been chosen to bring a new era of peace and prosperity to Meowville, and that they must use any means necessary to protect it.",
        person: 'Iris Pawkins',
    },
    82: {
        text:"Their beliefs are often seen as radical and dangerous by other citizens of Meowville.",
        person: 'Iris Pawkins',
    },
    83 : {
        text: "What's so dangerous about them I'd say we crush them.",
        person: 'Killerclaw Furr'
    },
    84: {
        text:"They use dark magic!",
        person: 'Iris Pawkins',
        index: 84,
        options: {
            1: {
                question: 'Dark Magic?',
                nestedStoryObject : {
                    1 : {
                        text: "Dark magic, also known as black magic, is a type of magic that draws on malevolent powers, and may be used for negative purposes, such as causing harm or misfortune to others",
                        person: 'Iris Pawkins',
                    },
                    2 : {
                        text: "It is believed to be associated with dark forces, such as evil spirits, demons, and the Devil, and is often seen as the antithesis of white magic, which is used for good.",
                        person: 'Iris Pawkins',
                    },
                }
            },
            2: {
                question: 'Wait, magic exists ?',
                nestedStoryObject : {
                    1 : {
                        text: "Right you don’t have any memories.",
                        person: 'Iris Pawkins',
                    },
                    2 : {
                        text: "So this must be pretty confusing to you. I will explain",
                        person: 'Iris Pawkins',
                    },
                }
            },
        }
    },
    85 : {
        text: "My magical power is Shape Shifting.",
        person: 'Iris Pawkins',
    },
    86: {
        text:"My magical power is a magic shield.",
        person: 'John Furrball',
    },
    87: {
        text:"My magic shield is a powerful defensive tool that I can use to protect myself from any danger.",
        person: 'John Furrball',
    },
    88: {
        text:"It's a bright, shimmering barrier that glows with a magical aura and can absorb any incoming attack.",
        person: 'John Furrball',
    },
    89: {
        text:"It's perfect for blocking attacks from enemies, protecting me from harm, and even reflecting back harmful spells.",
        person: 'John Furrball',
    },
    90: {
        text:"With this magical shield, I can be sure I'm safe no matter what comes my way!",
        person: 'John Furrball',
    },
    91 : {
        text: "What are you guys talking about ?",
        person: 'Killerclaw Furr'
    },
    92 : {
        text: "Well I like to tease player quite a lot but this is going way too far now.",
        person: 'Sunny Paws',
    },
    93 : {
        text: "I have the magical power of a god I can create words at will.",
        person: 'Romeo Paws'
    },
    94 : {
        text: "I am sorry. But the way you looked at me when I said dark magic I simply couldn't resist.",
        person: 'Iris Pawkins',
    },
    95: {
        text:"Yeah sorry me and Iris we used to do this all the time back in the days.",
        person: 'John Furrball',
    },
    96 : {
        text: "Yeah so back to the topic at hand. Now that we aren't so tense anymore.",
        person: 'Iris Pawkins',
    },
    97 : {
        text: "They are dangerous because of their occult practices and alchemy abuse. The stakes are high, for even the slightest mistake could result in catastrophic consequences.",
        person: 'Iris Pawkins',
        music: 4,
    },
    98: {
        text:"True we don't want to repeat what we had centuries ago.",
        person: 'John Furrball',
    },
    99: {
        text:"Wait, Now this isn't a joke ?",
        person: 'Killerclaw Furr'
    },
    100: {
        text:"I'm afraid not.",
        person: 'John Furrball',
    },
    101: {
        text: "How do you not know about those things Killerclaw? Are you the one with the lost memories?",
        person: 'Romeo Paws'
    },
    102: {
        text:"Well history lessons were never a real interest of mine to be honest..",
        person: 'Killerclaw Furr',
        index: 102,
        options: {
            1: {
                question: 'I still like you regardless.',
                nestedStoryObject : {
                    1 : {
                        text: "Thanks buddy! You are the best.",
                        person: 'Killerclaw Furr',
                    },
                
                }
            },
            2: {
                question: 'Dude!',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: " I am sorry. I guess I am just a boar man …",
                        person:  'Killerclaw Furr',
                    },
                   
                }
            },
        }
    },
    103: {
        text: "Excuse me for asking Sunny, but you and player went to the hospital already right ?",
        person: 'Romeo Paws'
    },
    104: {
        text: "Oh…. Right the hospital haha…",
        person: 'Sunny Paws',
    },
    105 : {
        text: "No way …",
        person: 'Iris Pawkins',
        index: 105,
        options: {
            1: {
                question: 'We went to the hospital already!',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "What did they say ?",
                        person: 'Iris Pawkins',
                    },
                    2 : {
                        text: "No we did not! Please don't lie, for me.",
                        person: 'Sunny Paws',
                    },
                
                }
            },
            2: {
                question: 'Say nothing.',
                nestedStoryObject : {
                    1 : {
                        text: "Alright...",
                        person: 'Iris Pawkins',
                    },
                   
                }
            },
        }
    },
    106: {
        text:"Alright then, sounds like you two go see the doctor first before we do anything else.",
        person: 'John Furrball',
    },
    107: {
        text:"Hey what about me?",
        person: 'Killerclaw Furr'
    },
    108: {
        text:"You could just go home?",
        person: 'John Furrball',
        index: 108,
        options: {
            1: {
                question: 'Yeah go home.',
                nestedStoryObject : {
                    1 : {
                        text: "But what about the epic adventure? I thought we are friends and friends help each other out don't they? ",
                        person: 'Killerclaw Furr'
                    },
                    2 : {
                        text: "We could use all the hands we get so John, leave him be.",
                        person: 'Iris Pawkins',
                    },
                    3 : {
                        text: "As you wish Iris. You always knew better than me. Just don't get in the way Killerclaw. ",
                        person: 'John Furrball',
                    },
                
                }
            },
            2: {
                question: 'No, don’t be so mean.',
                nestedStoryObject : {
                    1 : {
                        text: "I was concerned about the group's well being. If we have someone running around like him just begging for a fight. We surely would be in real trouble.",
                        person: 'John Furrball',
                    },
                    2 : {
                        text: "Don't worry, I'll make sure to check with my friend player before doing anything that might make you feel anxious.",
                        person: 'Killerclaw Furr'
                    },
                    3 : {
                        text: "Somehow that makes it even worse.",
                        person: 'John Furrball',
                    },
                    4 : {
                        text: "Ah just forget I said anything.",
                        person: 'John Furrball',
                    },
                   
                }
            },
        }
    },
    109: {
        text: "Right so what's the plan now?",
        person: 'Romeo Paws'
    },
    110 : {
        text: "I'd say. player and Sunny go to the hospital and check with the doctor and we have to do some digging and find out more about the Doggies.",
        person: 'Iris Pawkins',
    },
    111 : {
        text: "But first we all should get some sleep. How does that sound?",
        person: 'Iris Pawkins',
    },
    112: {
        text: "I agree.",
        person: 'Romeo Paws'
    },
    113: {
        text: "Also Sunny is already sound asleep so there is no point in walking home. I suggest we all just sleep here.",
        person: 'Romeo Paws'
    },
    114 : {
        text: "Fine, I got some spare pillows and blankets, you guys can use them.",
        person: 'Iris Pawkins',
    },
    115 : {
        text: "You never change Iris. Always sleeping in the library.",
        person: 'John Furrball',
    },
    116 : {
        text: "Well, I do love books and sometimes I just forget the time while reading them so I brought some pillows and blankets just in case.",
        person: 'Iris Pawkins',
    },
    117 : {
        text: "If only there were something to eat too",
        person: 'Killerclaw Furr'
    },
    118: {
        text: "Didn't you just eat half of the entire sweets?",
        person: 'Romeo Paws'
    },
    119 : {
        text: "We should all go to bed now. We have lots of work to do in the morning.",
        person: 'Iris Pawkins',
    },
    120 : {
        text: "Right.",
        person: 'John Furrball',
    },
    121: {
        text: "Yeah!",
        person: 'Romeo Paws'
    },
    122: {
        text: "By the time the sun started to rise, everyone in the library had awoken from their slumber. The morning light shone through the windows, illuminating the bookshelves and giving the room a warm, inviting ambiance.",
        person: '',
        background: 3,
        music: 3,
        effect: 1,
    },
    123: {
        text: "As people began to stir, the library seemed to come alive as conversations started and laughter filled the air.",
        person: ''
    },
    124 : {
        text: "John I have another one.",
        person: 'Iris Pawkins',
    },
    125 : {
        text: "Why did the cat cross the road? To get to the meow-seum!",
        person: 'Iris Pawkins',
    },
    126 : {
        text: "Ahah okay, This one wasn't as good as the other one.",
        person: 'John Furrball',
    },
    127 : {
        text: " Oh look who is awake. Rise and shine sleepy head.",
        person: 'John Furrball',
        index: 127,
        options: {
            1: {
                question: 'Good morning.',
                nestedStoryObject : {
                    1 : {
                        text: "It seems like you two had an interesting night.",
                        person: 'John Furrball',
                    },
                    2 : {
                        text: "Sister! What are you doing!",
                        person: 'Romeo Paws'
                    },
                }
            },
        }
    },
    128 : {
        text: "Oh? Ooooh, my apologies, I mistook you for my beloved pillow.",
        person: 'Sunny Paws',
        index: 128,
        options: {
            1: {
                question: "I don't mind it",
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Oh really? Well then, let me make it up to you by treating you to a romantic breakfast.",
                        person: 'Sunny Paws',
                    },
                    2: {
                        text: "What do you say?",
                        person: 'Sunny Paws',
                    },
                    3 : {
                        text: "Wait, what!",
                        person: 'Romeo Paws'
                    },
                    4 : {
                        text: "Oh I want a romantic breakfast too!",
                        person: 'Killerclaw Furr'
                    },
                    5 : {
                        text: "No one asked you Killerclaw!",
                        person: 'Romeo Paws'
                    },
                    6: {
                        text: "Oh did I say that out loud!",
                        person: 'Sunny Paws',
                    },
                }
            },
            2: {
                question: 'Get off of me',
                nestedStoryObject : {
                    1 : {
                        text: "Hey, that's my dear sister! Please, show her some kindness and respect!",
                        person: 'Romeo Paws'
                    },
                    2 : {
                        text: "No it's alright Romeo.",
                        person: 'Sunny Paws',
                    },
                    3 : {
                        text: "It's my fault. I'm so sorry about this.",
                        person: 'Sunny Paws',
                    },

                }
            },
        }
    },
    129 : {
        text: "Alright, time to eat guys!",
        person: 'Iris Pawkins',
    },
    130 : {
        text: "I didn't know you can cook Iris ?",
        person: 'Killerclaw Furr'
    },
    131 : {
        text: "Weren't you two together ?",
        person: 'John Furrball',
    },
    132 : {
        text: "Yes we were together for a few months. But he never gave me an opportunity to show off my culinary skills since he was always running off somewhere.",
        person: 'Iris Pawkins',
    },
    133 : {
        text: "Why did you even fall for this guy anyway? ",
        person: 'Romeo Paws'
    },
    134 : {
        text: "Hey I'm right here you guys. I can hear you…",
        person: 'Killerclaw Furr'
    },
    135 : {
        text: "Well, I guess I was just looking for something different.",
        person: 'Iris Pawkins',
    },
    136 : {
        text: "Anyway, let's eat!",
        person: 'John Furrball',
    },
    137 : {
        text: "After breakfast, player and Sunny made their way to the hospital while the others stayed back doing research on the Doggies. ",
        person: '',
        background: 1,
        music: 1,
        effect: 4,
    },
    138 : {
        text: "Do you think history will repeat itself and the horrors of the past will be reborn once more? Will the atrocities committed by the Doggies be resurrected to haunt us anew?",
        person: 'Sunny Paws',
        index: 138,
        options: {
            1: {
                question: 'Probably.',
                nestedStoryObject : {
                    1 : {
                        text: "That would be devastating. No one wants to think about the horrors of the past repeating themselves, but it is a possibility.",
                        person: 'Sunny Paws',
                    },
                    2 : {
                        text: " We can only hope that lessons learned from the past will help us to prevent such tragedies from occurring again.",
                        person: 'Sunny Paws',
                    },
                    3 : {
                        text: "However, it is important to remember that we must remain vigilant in order to avoid any potential recurrences of such atrocities.",
                        person: 'Sunny Paws',
                    },
                }
            },
            2: {
                question: 'There is no way.',
                playerScore: 1,
                nestedStoryObject : {
                    1 : {
                        text: "Yeah I agree.",
                        person: 'Sunny Paws',
                    },
                    2 : {
                        text: "After all it is just a story from the past. Let's just forget the past.",
                        person: 'Sunny Paws',
                    },
                }
            },
        }
    },
    139 : {
        text: " Mhmm what's that ?",
        person: 'Sunny Paws',
        totalPoints: 13,
        isEnd: true,
        index: 139,
        options: {
            1: {
                question: 'Why are we in the forest again?',
                pass: {
                    1: {
                        text: "Well, you see, my heart is overflowing with love for you and I can no longer keep it a secret--I must confess my feelings to you! ",
                        person: 'Sunny Paws',
                    },
                    2: {
                        text: "But before I can love you, I must take care of something, so please forgive me and do not try to find me until then farewell.",
                        person: 'Sunny Paws',
                    },
                    3: {
                        text: "player is laying motionless on the ground, the last echoes of Sunny's voice fading into the distance. They had been knocked out cold and all they could do was watch as she vanished into the horizon.",
                        person: '',
                    },
                    4: {
                        text: "The sun began to set and the night grew dark, but the mystery remained unsolved. What had happened to Sunny and why had they disappeared?",
                        person: '',
                    },
                    5: {
                        text: "Unfortunately, these were questions that would remain unanswered for now, and player was left with nothing but the fading memory of the one who confessed their love to them.",
                        person: '',
                    },
                    6: {
                        text: "Be continued ...",
                        person: '',
                    },
                },

                notPass: {
                    1: {
                        text: "Well, you see I was the one who removed your memories! ",
                        person: 'Sunny Paws',
                    },
                    2: {
                        text: "You probably ask yourself why?",
                        person: 'Sunny Paws',
                    },
                    3: {
                        text: "It's simple really.",
                        person: 'Sunny Paws',
                    },
                    4: {
                        text: "As part of a grand magical ritual, I needed a powerful sacrifice to the dark lord, and what better choice than you?",
                        person: 'Sunny Paws',
                    },
                    5: {
                        text: "After all, in order to create something new, we must first destroy what is already there.",
                        person: 'Sunny Paws',
                    },
                    6: {
                        text: "Also magic does exist, it no longer matters to you. Now that your memories have been taken away, you will serve as the perfect offering.",
                        person: 'Sunny Paws',
                    },
                    7: {
                        text: "The dark lord was pleased with the offering, and soon the ritual was complete. The power of the ritual was strong, and it had the desired effect.",
                        person: '',
                    },
                    8: {
                        text: "The world around them was transformed, and a new era had begun",
                        person: '',
                    },
                    9: {
                        text: "As the sun set on the horizon, the people of the land looked to the sky in awe, knowing that a great power had been unleashed.",
                        person: '',
                    },
                    10: {
                        text: "The sacrifice had been made, and the new dawn was upon them.",
                        person: '',
                    },
                }
            },
        
        }

    },

}